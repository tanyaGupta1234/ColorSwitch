public class Obstacle  extends GameComponent{
    public Obstacle(double y) {
        super(y);
    }
}
