
public class Star extends GameComponent 
{
	public Star(double y)
	{
        super(y);
       
    }

}
