import javafx.scene.image.Image;

public class Player extends GameComponent {
    private double speed;
    int score;


    public Player(double y){
        super(y);
        speed=0;
    }


}
